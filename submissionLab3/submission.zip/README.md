# MapReduce

ENSC 351 Lab 3 submission
Nicolas Klaassen
Diane Wolf
Galen Elfert

Our lab report is in 351-L3-Report.pdf

to build, from this directory:
1. `mkdir build && cd build`
2. `cmake ..`
3. `make`
